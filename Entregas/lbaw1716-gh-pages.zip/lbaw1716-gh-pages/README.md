# LBAW

  * GROUP1716

    * THEME: Online Auctions

    * ELEMENTS:

		* Diogo Peixoto Pereira, diogopeixotopereira@gmail.com
    	* Igor Bernardo Amorim Silveira, igorasilveira@gmail.com
    	* Nádia de Sousa Varela de Carvalho, nadiacarvalho118@gmail.com
    	* Pedro Miguel Ferraz Nogueira da Silva, pedronogueirasilva5@gmail.com


    * A3 -> A fazer:

      * Nádia:

        - My Auctions User - com seus proprios leiloes à venda (selling) e que ele tem bid (bidding)
        - My Auctions Mod - com os leiloes pendentes de aceitar que o sistema lhe atribuiu bem como os já aceites e que sao da sua responsabilidade

      * Diogo:

        - Home Page
        - Administrator

      * Pedro:

        - Login
        - Register
        - About

      * Igor:

        - Criar Auction
        - Perfil

(https://diogopp.github.io/lbaw1716)
